import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  age: integer("age").notNull(),
  gender: text("gender").notNull(),
  height: real("height").notNull(), // cm
  weight: real("weight").notNull(), // kg
  targetWeight: real("target_weight").notNull(), // kg
  activityLevel: text("activity_level").notNull(),
  goal: text("goal").notNull(), // lose_weight, build_muscle, maintain_weight
  timeline: text("timeline").notNull(), // 1_month, 3_months, 6_months, 1_year, 2_years
  dailyCalorieTarget: integer("daily_calorie_target").notNull(),
  proteinTarget: integer("protein_target").notNull(),
  carbsTarget: integer("carbs_target").notNull(),
  fatsTarget: integer("fats_target").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const meals = pgTable("meals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  imageUrl: text("image_url"),
  calories: integer("calories").notNull(),
  protein: real("protein").notNull(),
  carbs: real("carbs").notNull(),
  fats: real("fats").notNull(),
  fiber: real("fiber"),
  sodium: real("sodium"),
  sugar: real("sugar"),
  analysisData: jsonb("analysis_data"), // Raw AI analysis response
  loggedAt: timestamp("logged_at").defaultNow(),
});

export const dailyProgress = pgTable("daily_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
  totalCalories: integer("total_calories").default(0),
  totalProtein: real("total_protein").default(0),
  totalCarbs: real("total_carbs").default(0),
  totalFats: real("total_fats").default(0),
  currentWeight: real("current_weight"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  dailyCalorieTarget: true,
  proteinTarget: true,
  carbsTarget: true,
  fatsTarget: true,
});

export const insertMealSchema = createInsertSchema(meals).omit({
  id: true,
  loggedAt: true,
});

export const insertDailyProgressSchema = createInsertSchema(dailyProgress).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMeal = z.infer<typeof insertMealSchema>;
export type Meal = typeof meals.$inferSelect;
export type InsertDailyProgress = z.infer<typeof insertDailyProgressSchema>;
export type DailyProgress = typeof dailyProgress.$inferSelect;
