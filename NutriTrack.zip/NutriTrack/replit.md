# Overview

This is a nutrition tracking and fitness application called NutriVision that allows users to analyze meals through photo uploads using AI, track daily nutrition intake, and monitor progress towards fitness goals. The app features a mobile-first design with onboarding, meal logging, progress tracking, and user profile management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state management and data fetching
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design
- **Styling**: Tailwind CSS with CSS variables for theming support
- **Form Handling**: React Hook Form with Zod for validation

## Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with endpoints for users, meals, and progress tracking
- **File Upload**: Multer for handling image uploads with memory storage
- **Development**: Custom Vite middleware integration for hot reloading

## Data Storage
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Design**: Three main entities - users, meals, and daily progress tracking
- **Migrations**: Drizzle Kit for database schema management
- **Connection**: Neon Database serverless connection

## Authentication and User Management
- **User Storage**: Local storage for user session persistence
- **No Authentication**: Simple user creation and storage without traditional auth flows
- **User Profiles**: Comprehensive fitness profiles with goals, targets, and personal metrics

## External Dependencies

### AI and Image Processing
- **OpenAI GPT-4o**: For analyzing meal photos and extracting nutritional information
- **Image Upload**: Base64 image processing with file size limits

### Database and Infrastructure
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle ORM**: Type-safe database operations and schema management

### UI and Visualization
- **Recharts**: Chart library for progress visualization and data trends
- **Embla Carousel**: Carousel component for UI interactions
- **React Day Picker**: Calendar component for date selection

### Development Tools
- **Replit Integration**: Custom plugins for development environment
- **ESBuild**: Fast JavaScript bundling for production builds
- **PostCSS**: CSS processing with Tailwind CSS compilation

### Core Libraries
- **TanStack React Query**: Server state management and caching
- **React Hook Form**: Form state management and validation
- **Zod**: Runtime type validation and schema definition
- **Date-fns**: Date manipulation and formatting utilities