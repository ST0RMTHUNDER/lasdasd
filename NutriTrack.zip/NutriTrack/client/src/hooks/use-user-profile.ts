import { useState, useEffect } from "react";
import type { User } from "@shared/schema";

export function useUserProfile() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get user from localStorage
    const storedUser = localStorage.getItem("nutrivision_user");
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Error parsing stored user:", error);
        localStorage.removeItem("nutrivision_user");
      }
    }
    setLoading(false);
  }, []);

  const saveUser = (userData: User) => {
    setUser(userData);
    localStorage.setItem("nutrivision_user", JSON.stringify(userData));
  };

  const clearUser = () => {
    setUser(null);
    localStorage.removeItem("nutrivision_user");
  };

  return {
    user,
    saveUser,
    clearUser,
    loading,
    isAuthenticated: !!user,
  };
}
