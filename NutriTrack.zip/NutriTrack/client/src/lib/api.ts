import { apiRequest } from "./queryClient";
import type { User, InsertUser, Meal, InsertMeal, DailyProgress } from "@shared/schema";

export interface NutritionAnalysis {
  description: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  sodium?: number;
  sugar?: number;
  confidence: number;
}

export const api = {
  // User operations
  createUser: async (userData: InsertUser): Promise<User> => {
    const response = await apiRequest("POST", "/api/users", userData);
    return response.json();
  },

  getUser: async (userId: string): Promise<User> => {
    const response = await apiRequest("GET", `/api/users/${userId}`);
    return response.json();
  },

  updateUser: async (userId: string, updates: Partial<User>): Promise<User> => {
    const response = await apiRequest("PATCH", `/api/users/${userId}`, updates);
    return response.json();
  },

  // Meal analysis
  analyzeMealImage: async (imageFile: File): Promise<NutritionAnalysis> => {
    const formData = new FormData();
    formData.append('image', imageFile);
    
    const response = await fetch("/api/analyze-meal", {
      method: "POST",
      body: formData,
      credentials: "include",
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Failed to analyze meal: ${error}`);
    }

    return response.json();
  },

  // Meal logging
  createMeal: async (mealData: InsertMeal): Promise<Meal> => {
    const response = await apiRequest("POST", "/api/meals", mealData);
    return response.json();
  },

  getUserMeals: async (userId: string, limit?: number): Promise<Meal[]> => {
    const url = limit ? `/api/users/${userId}/meals?limit=${limit}` : `/api/users/${userId}/meals`;
    const response = await apiRequest("GET", url);
    return response.json();
  },

  // Progress tracking
  getDailyProgress: async (userId: string, date: string): Promise<DailyProgress> => {
    const response = await apiRequest("GET", `/api/progress/${userId}/${date}`);
    return response.json();
  },

  getDailyProgressRange: async (userId: string, startDate: string, endDate: string): Promise<DailyProgress[]> => {
    const response = await apiRequest("GET", `/api/progress/${userId}/range?startDate=${startDate}&endDate=${endDate}`);
    return response.json();
  },
};
