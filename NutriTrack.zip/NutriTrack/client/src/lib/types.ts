export interface UserProfile {
  id?: string;
  username: string;
  email: string;
  age: number;
  gender: 'male' | 'female';
  height: number; // cm
  weight: number; // kg
  targetWeight: number; // kg
  activityLevel: 'sedentary' | 'lightly_active' | 'moderately_active' | 'very_active' | 'extremely_active';
  goal: 'lose_weight' | 'build_muscle' | 'maintain_weight';
  timeline: '1_month' | '3_months' | '6_months' | '1_year' | '2_years';
  dailyCalorieTarget?: number;
  proteinTarget?: number;
  carbsTarget?: number;
  fatsTarget?: number;
}

export interface NutritionAnalysis {
  foodItems: string[];
  totalCalories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  sodium?: number;
  sugar?: number;
  confidence: number;
  description: string;
}

export interface MealData {
  id?: string;
  userId: string;
  name: string;
  imageUrl?: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  sodium?: number;
  sugar?: number;
  analysisData?: NutritionAnalysis;
  loggedAt?: Date;
}

export interface DailyProgress {
  id?: string;
  userId: string;
  date: string;
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFats: number;
  currentWeight?: number;
}
