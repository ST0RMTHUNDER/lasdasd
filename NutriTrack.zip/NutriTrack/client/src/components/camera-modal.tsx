import { useState, useRef } from "react";
import { useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Camera, Image, X } from "lucide-react";
import type { NutritionAnalysis } from "@/lib/types";

interface CameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnalysisComplete: (analysis: NutritionAnalysis, imageUrl: string) => void;
}

export default function CameraModal({ isOpen, onClose, onAnalysisComplete }: CameraModalProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const analyzeMealMutation = useMutation({
    mutationFn: async (base64Image: string) => {
      const response = await apiRequest("POST", "/api/analyze-meal-base64", {
        image: base64Image
      });
      return response.json();
    },
    onSuccess: (analysis: NutritionAnalysis, variables: string) => {
      setIsAnalyzing(false);
      onAnalysisComplete(analysis, variables);
    },
    onError: (error) => {
      setIsAnalyzing(false);
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      setIsAnalyzing(true);
      analyzeMealMutation.mutate(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleCameraCapture = () => {
    // For web browsers, we'll use the file input with camera capture
    if (fileInputRef.current) {
      fileInputRef.current.setAttribute('capture', 'camera');
      fileInputRef.current.click();
    }
  };

  const handleGallerySelect = () => {
    // Remove camera capture attribute for gallery selection
    if (fileInputRef.current) {
      fileInputRef.current.removeAttribute('capture');
      fileInputRef.current.click();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Add Meal
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-camera"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
            data-testid="input-file-upload"
          />
          
          <Button
            onClick={handleCameraCapture}
            disabled={isAnalyzing}
            className="w-full flex items-center space-x-4 p-6 h-auto justify-start"
            variant="outline"
            data-testid="button-take-photo"
          >
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
              <Camera className="text-primary" size={24} />
            </div>
            <div className="text-left">
              <div className="font-semibold text-neutral-800">Take Photo</div>
              <div className="text-sm text-gray-600">Use camera to capture your meal</div>
            </div>
          </Button>
          
          <Button
            onClick={handleGallerySelect}
            disabled={isAnalyzing}
            className="w-full flex items-center space-x-4 p-6 h-auto justify-start"
            variant="outline"
            data-testid="button-select-photo"
          >
            <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
              <Image className="text-secondary" size={24} />
            </div>
            <div className="text-left">
              <div className="font-semibold text-neutral-800">Choose from Gallery</div>
              <div className="text-sm text-gray-600">Select an existing photo</div>
            </div>
          </Button>

          {isAnalyzing && (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-gray-600">Analyzing your meal...</p>
              <p className="text-sm text-gray-500 mt-2">This may take a few seconds</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
