import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { X, CheckCircle } from "lucide-react";
import type { NutritionAnalysis, MealData } from "@/lib/types";

interface AnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  analysis: NutritionAnalysis;
  imageUrl: string | null;
  userId: string;
  onMealLogged: () => void;
}

export default function AnalysisModal({ 
  isOpen, 
  onClose, 
  analysis, 
  imageUrl, 
  userId,
  onMealLogged 
}: AnalysisModalProps) {
  const [mealName, setMealName] = useState(analysis.foodItems.join(", ") || "My Meal");
  const [isLogging, setIsLogging] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const logMealMutation = useMutation({
    mutationFn: async (mealData: Omit<MealData, 'id' | 'loggedAt'>) => {
      const response = await apiRequest("POST", "/api/meals", mealData);
      return response.json();
    },
    onSuccess: () => {
      setIsLogging(false);
      toast({
        title: "Meal Logged!",
        description: "Your meal has been added to your food log.",
      });
      
      // Invalidate and refetch relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/meals", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/progress", userId, "today"] });
      
      onMealLogged();
    },
    onError: (error) => {
      setIsLogging(false);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleLogMeal = () => {
    setIsLogging(true);
    
    const mealData: Omit<MealData, 'id' | 'loggedAt'> = {
      userId,
      name: mealName,
      imageUrl: imageUrl || undefined,
      calories: analysis.totalCalories,
      protein: analysis.protein,
      carbs: analysis.carbs,
      fats: analysis.fats,
      fiber: analysis.fiber,
      sodium: analysis.sodium,
      sugar: analysis.sugar,
      analysisData: analysis,
    };

    logMealMutation.mutate(mealData);
  };

  const proteinPercentage = Math.round((analysis.protein * 4 / analysis.totalCalories) * 100);
  const carbsPercentage = Math.round((analysis.carbs * 4 / analysis.totalCalories) * 100);
  const fatsPercentage = Math.round((analysis.fats * 9 / analysis.totalCalories) * 100);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            Meal Analysis
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-analysis"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Meal Image */}
          {imageUrl && (
            <div className="mb-6">
              <img 
                src={imageUrl} 
                alt="Analyzed meal" 
                className="w-full h-48 rounded-xl object-cover"
                data-testid="img-analyzed-meal"
              />
            </div>
          )}

          {/* AI Analysis Results */}
          <div>
            <h4 className="font-semibold text-neutral-800 mb-3">AI Analysis Results</h4>
            <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-4">
              <div className="flex items-center space-x-2 mb-2">
                <CheckCircle className="text-green-500" size={20} />
                <span className="font-medium text-green-800">Analysis Complete</span>
              </div>
              <p className="text-sm text-green-700" data-testid="text-analysis-description">
                {analysis.description}
              </p>
            </div>
          </div>

          {/* Meal Name Input */}
          <div>
            <Label htmlFor="mealName">Meal Name</Label>
            <Input
              id="mealName"
              value={mealName}
              onChange={(e) => setMealName(e.target.value)}
              placeholder="Enter meal name"
              className="mt-1"
              data-testid="input-meal-name"
            />
          </div>

          {/* Nutrition Breakdown */}
          <div>
            <h4 className="font-semibold text-neutral-800 mb-4">Nutrition Breakdown</h4>
            
            {/* Total Calories */}
            <div className="bg-primary/10 rounded-xl p-4 mb-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary" data-testid="text-total-calories">
                  {analysis.totalCalories}
                </div>
                <div className="text-sm text-gray-600">Total Calories</div>
              </div>
            </div>

            {/* Macros Grid */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-blue-600" data-testid="text-protein-amount">
                  {Math.round(analysis.protein)}g
                </div>
                <div className="text-sm text-gray-600">Protein</div>
                <div className="text-xs text-gray-500 mt-1">{proteinPercentage}% of calories</div>
              </div>
              
              <div className="bg-yellow-50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-yellow-600" data-testid="text-carbs-amount">
                  {Math.round(analysis.carbs)}g
                </div>
                <div className="text-sm text-gray-600">Carbs</div>
                <div className="text-xs text-gray-500 mt-1">{carbsPercentage}% of calories</div>
              </div>
              
              <div className="bg-green-50 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-green-600" data-testid="text-fats-amount">
                  {Math.round(analysis.fats)}g
                </div>
                <div className="text-sm text-gray-600">Fats</div>
                <div className="text-xs text-gray-500 mt-1">{fatsPercentage}% of calories</div>
              </div>
            </div>
          </div>

          {/* Additional Nutrients */}
          {(analysis.fiber || analysis.sodium || analysis.sugar) && (
            <div>
              <h4 className="font-semibold text-neutral-800 mb-3">Additional Nutrients</h4>
              <div className="space-y-3">
                {analysis.fiber && (
                  <div className="flex justify-between items-center py-2">
                    <span className="text-gray-700">Fiber</span>
                    <span className="font-medium" data-testid="text-fiber-amount">
                      {Math.round(analysis.fiber)}g
                    </span>
                  </div>
                )}
                {analysis.sodium && (
                  <div className="flex justify-between items-center py-2">
                    <span className="text-gray-700">Sodium</span>
                    <span className="font-medium" data-testid="text-sodium-amount">
                      {Math.round(analysis.sodium)}mg
                    </span>
                  </div>
                )}
                {analysis.sugar && (
                  <div className="flex justify-between items-center py-2">
                    <span className="text-gray-700">Sugar</span>
                    <span className="font-medium" data-testid="text-sugar-amount">
                      {Math.round(analysis.sugar)}g
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Confidence Score */}
          <div className="text-center text-sm text-gray-600">
            Analysis Confidence: {Math.round(analysis.confidence * 100)}%
          </div>

          {/* Add to Log Button */}
          <Button 
            onClick={handleLogMeal}
            disabled={isLogging || !mealName.trim()}
            className="w-full py-4 font-semibold"
            data-testid="button-log-meal"
          >
            {isLogging ? "Logging Meal..." : "Add to Food Log"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
