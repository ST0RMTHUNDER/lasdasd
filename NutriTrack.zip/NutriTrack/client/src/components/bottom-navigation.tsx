import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, BarChart, User } from "lucide-react";

interface BottomNavigationProps {
  activeTab: 'home' | 'progress' | 'profile';
}

export default function BottomNavigation({ activeTab }: BottomNavigationProps) {
  const [, setLocation] = useLocation();

  const navigationItems = [
    {
      id: 'home',
      label: 'Home',
      icon: Home,
      path: '/home'
    },
    {
      id: 'progress',
      label: 'Progress',
      icon: BarChart,
      path: '/progress'
    },
    {
      id: 'profile',
      label: 'Profile',
      icon: User,
      path: '/profile'
    }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 mobile-container mx-auto z-50">
      <div className="grid grid-cols-3 h-16">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => setLocation(item.path)}
              className={`flex flex-col items-center justify-center space-y-1 h-full rounded-none ${
                isActive ? 'text-primary' : 'text-gray-500 hover:text-primary'
              }`}
              data-testid={`button-nav-${item.id}`}
            >
              <Icon size={20} />
              <span className="text-xs font-medium">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
