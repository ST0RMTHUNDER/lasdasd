import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import type { DailyProgress } from '@/lib/types';

interface ProgressChartProps {
  data: DailyProgress[];
}

export default function ProgressChart({ data }: ProgressChartProps) {
  const chartData = data.map(day => ({
    date: new Date(day.date).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }),
    calories: day.totalCalories,
    protein: day.totalProtein,
    weight: day.currentWeight || 0
  }));

  if (chartData.length === 0) {
    return (
      <div className="h-48 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-2">📊</div>
          <div className="text-gray-600">Progress chart</div>
          <div className="text-sm text-gray-500">Start logging meals to see your progress</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-48 w-full" data-testid="chart-progress">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="date" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              fontSize: '12px'
            }}
          />
          <Line 
            type="monotone" 
            dataKey="calories" 
            stroke="hsl(142, 76%, 36%)"
            strokeWidth={2}
            dot={{ fill: 'hsl(142, 76%, 36%)', strokeWidth: 2, r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
