import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Camera, ChartLine, Target, ArrowLeft, User, Scale } from "lucide-react";
import type { UserProfile } from "@/lib/types";

const personalInfoSchema = z.object({
  username: z.string().min(2, "Username must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  age: z.number().min(13).max(120),
  gender: z.enum(["male", "female"]),
  height: z.number().min(100).max(250),
  weight: z.number().min(30).max(300),
  activityLevel: z.enum(["sedentary", "lightly_active", "moderately_active", "very_active", "extremely_active"]),
});

const goalSchema = z.object({
  goal: z.enum(["lose_weight", "build_muscle", "maintain_weight"]),
  targetWeight: z.number().min(30).max(300),
  timeline: z.enum(["1_month", "3_months", "6_months", "1_year", "2_years"]),
});

type PersonalInfo = z.infer<typeof personalInfoSchema>;
type GoalInfo = z.infer<typeof goalSchema>;

export default function Onboarding() {
  const [step, setStep] = useState<'welcome' | 'personal' | 'goals'>('welcome');
  const [personalInfo, setPersonalInfo] = useState<PersonalInfo | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const personalForm = useForm<PersonalInfo>({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      username: "",
      email: "",
      age: 25,
      gender: "male",
      height: 175,
      weight: 70,
      activityLevel: "moderately_active",
    },
  });

  const goalForm = useForm<GoalInfo>({
    resolver: zodResolver(goalSchema),
    defaultValues: {
      goal: "lose_weight",
      targetWeight: 65,
      timeline: "6_months",
    },
  });

  const createUserMutation = useMutation({
    mutationFn: async (userData: UserProfile) => {
      const response = await apiRequest("POST", "/api/users", userData);
      return response.json();
    },
    onSuccess: (user) => {
      localStorage.setItem("currentUserId", user.id);
      toast({
        title: "Welcome to NutriVision!",
        description: "Your profile has been created successfully.",
      });
      setLocation("/home");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePersonalInfoSubmit = (data: PersonalInfo) => {
    setPersonalInfo(data);
    setStep('goals');
  };

  const handleGoalSubmit = (goalData: GoalInfo) => {
    if (!personalInfo) return;
    
    const userData: UserProfile = {
      ...personalInfo,
      ...goalData,
    };
    
    createUserMutation.mutate(userData);
  };

  if (step === 'welcome') {
    return (
      <div className="h-screen flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
          <div className="w-24 h-24 gradient-bg rounded-3xl flex items-center justify-center mb-8 shadow-lg">
            <Camera className="text-white" size={32} />
          </div>
          
          <h1 className="text-3xl font-bold text-neutral-800 mb-4">Welcome to NutriVision</h1>
          <p className="text-lg text-gray-600 mb-8 leading-relaxed">
            Take a photo of any meal and get instant AI-powered nutrition analysis to reach your fitness goals
          </p>
          
          <div className="space-y-4 mb-8">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                <Camera className="text-primary" size={16} />
              </div>
              <span className="text-gray-700">Instant meal photo analysis</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center">
                <ChartLine className="text-secondary" size={16} />
              </div>
              <span className="text-gray-700">Track your progress visually</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
                <Target className="text-accent" size={16} />
              </div>
              <span className="text-gray-700">Achieve your fitness goals</span>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <Button 
            onClick={() => setStep('personal')} 
            className="w-full py-4 text-lg font-semibold"
            data-testid="button-get-started"
          >
            Get Started - It's Free!
          </Button>
          <p className="text-center text-sm text-gray-500 mt-3">No subscription required • Always free</p>
        </div>
      </div>
    );
  }

  if (step === 'personal') {
    return (
      <div className="h-screen flex flex-col">
        <div className="bg-white border-b border-gray-100 px-6 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setStep('welcome')}
              data-testid="button-back-welcome"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2 className="font-semibold text-lg text-neutral-800">Profile Setup</h2>
            <span className="text-sm text-primary font-medium">1 of 2</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-neutral-800 mb-2">Tell us about yourself</h3>
            <p className="text-gray-600">This helps us personalize your nutrition goals</p>
          </div>

          <Form {...personalForm}>
            <form onSubmit={personalForm.handleSubmit(handlePersonalInfoSubmit)} className="space-y-6">
              <FormField
                control={personalForm.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your username" {...field} data-testid="input-username" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={personalForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="your@email.com" {...field} data-testid="input-email" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={personalForm.control}
                name="age"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="25" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-age"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={personalForm.control}
                name="gender"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Gender</FormLabel>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        type="button"
                        variant={field.value === "male" ? "default" : "outline"}
                        className="py-6"
                        onClick={() => field.onChange("male")}
                        data-testid="button-gender-male"
                      >
                        <User className="mr-2 h-4 w-4" />
                        Male
                      </Button>
                      <Button
                        type="button"
                        variant={field.value === "female" ? "default" : "outline"}
                        className="py-6"
                        onClick={() => field.onChange("female")}
                        data-testid="button-gender-female"
                      >
                        <User className="mr-2 h-4 w-4" />
                        Female
                      </Button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={personalForm.control}
                  name="height"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Height (cm)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="175" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          data-testid="input-height"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={personalForm.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Weight (kg)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="70" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          data-testid="input-weight"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={personalForm.control}
                name="activityLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Activity Level</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-activity-level">
                          <SelectValue placeholder="Select activity level" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="sedentary">Sedentary (desk job, no exercise)</SelectItem>
                        <SelectItem value="lightly_active">Lightly active (light exercise 1-3 days/week)</SelectItem>
                        <SelectItem value="moderately_active">Moderately active (moderate exercise 3-5 days/week)</SelectItem>
                        <SelectItem value="very_active">Very active (hard exercise 6-7 days/week)</SelectItem>
                        <SelectItem value="extremely_active">Extremely active (physical job + exercise)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="pt-4">
                <Button type="submit" className="w-full py-4" data-testid="button-continue-personal">
                  Continue
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    );
  }

  if (step === 'goals') {
    return (
      <div className="h-screen flex flex-col">
        <div className="bg-white border-b border-gray-100 px-6 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setStep('personal')}
              data-testid="button-back-personal"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h2 className="font-semibold text-lg text-neutral-800">Your Goals</h2>
            <span className="text-sm text-primary font-medium">2 of 2</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          <div className="mb-6">
            <h3 className="text-xl font-bold text-neutral-800 mb-2">What's your main goal?</h3>
            <p className="text-gray-600">Choose your primary fitness objective</p>
          </div>

          <Form {...goalForm}>
            <form onSubmit={goalForm.handleSubmit(handleGoalSubmit)} className="space-y-6">
              <FormField
                control={goalForm.control}
                name="goal"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Primary Goal</FormLabel>
                    <div className="space-y-3">
                      <Card 
                        className={`cursor-pointer transition-colors ${field.value === 'lose_weight' ? 'ring-2 ring-primary' : ''}`}
                        onClick={() => field.onChange('lose_weight')}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mr-4">
                              <Scale className="text-red-500" size={20} />
                            </div>
                            <div>
                              <div className="font-semibold text-gray-800">Lose Weight</div>
                              <div className="text-sm text-gray-600">Create a caloric deficit</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card 
                        className={`cursor-pointer transition-colors ${field.value === 'build_muscle' ? 'ring-2 ring-primary' : ''}`}
                        onClick={() => field.onChange('build_muscle')}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mr-4">
                              <Target className="text-green-500" size={20} />
                            </div>
                            <div>
                              <div className="font-semibold text-gray-800">Build Muscle</div>
                              <div className="text-sm text-gray-600">Focus on protein and strength</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      <Card 
                        className={`cursor-pointer transition-colors ${field.value === 'maintain_weight' ? 'ring-2 ring-primary' : ''}`}
                        onClick={() => field.onChange('maintain_weight')}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
                              <ChartLine className="text-blue-500" size={20} />
                            </div>
                            <div>
                              <div className="font-semibold text-gray-800">Maintain Weight</div>
                              <div className="text-sm text-gray-600">Healthy lifestyle balance</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={goalForm.control}
                name="targetWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Target Weight (kg)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="65" 
                        {...field} 
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                        data-testid="input-target-weight"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={goalForm.control}
                name="timeline"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Timeline to reach goal</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-timeline">
                          <SelectValue placeholder="Select timeline" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="1_month">1 month</SelectItem>
                        <SelectItem value="3_months">3 months</SelectItem>
                        <SelectItem value="6_months">6 months</SelectItem>
                        <SelectItem value="1_year">1 year</SelectItem>
                        <SelectItem value="2_years">2+ years</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full py-4" 
                  disabled={createUserMutation.isPending}
                  data-testid="button-complete-setup"
                >
                  {createUserMutation.isPending ? "Creating Profile..." : "Complete Setup"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
    );
  }

  return null;
}
