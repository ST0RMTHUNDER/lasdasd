import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { User as UserIcon, Camera } from "lucide-react";
import CameraModal from "@/components/camera-modal";
import AnalysisModal from "@/components/analysis-modal";
import BottomNavigation from "@/components/bottom-navigation";
import type { User as UserType, DailyProgress, Meal } from "@shared/schema";
import type { NutritionAnalysis } from "@/lib/api";

export default function Home() {
  const [showCameraModal, setShowCameraModal] = useState(false);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<NutritionAnalysis | null>(null);
  const [analysisImage, setAnalysisImage] = useState<string | null>(null);
  const [, setLocation] = useLocation();
  
  const currentUserId = localStorage.getItem("currentUserId");

  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/users", currentUserId],
    enabled: !!currentUserId,
  });

  const { data: todayProgress } = useQuery<DailyProgress>({
    queryKey: ["/api/progress", currentUserId, "today"],
    enabled: !!currentUserId,
  });

  const { data: recentMeals } = useQuery<Meal[]>({
    queryKey: ["/api/meals", currentUserId],
    enabled: !!currentUserId,
  });

  const handleAnalysisComplete = (result: NutritionAnalysis, imageUrl: string) => {
    setAnalysisResult(result);
    setAnalysisImage(imageUrl);
    setShowCameraModal(false);
    setShowAnalysisModal(true);
  };

  const handleMealLogged = () => {
    setShowAnalysisModal(false);
    setAnalysisResult(null);
    setAnalysisImage(null);
  };

  if (!user || !todayProgress) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const caloriesProgress = (todayProgress.totalCalories || 0) / user.dailyCalorieTarget * 100;
  const proteinProgress = user.proteinTarget ? (todayProgress.totalProtein || 0) / user.proteinTarget * 100 : 0;
  const carbsProgress = user.carbsTarget ? (todayProgress.totalCarbs || 0) / user.carbsTarget * 100 : 0;
  const fatsProgress = user.fatsTarget ? (todayProgress.totalFats || 0) / user.fatsTarget * 100 : 0;

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Status Bar Spacer */}
      <div className="h-6 bg-white"></div>
      
      {/* Header */}
      <div className="bg-white px-6 py-4 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-800" data-testid="text-welcome">
              Hello, {user.username}!
            </h1>
            <p className="text-gray-600 text-sm">Let's track your nutrition today</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-gray-100"
            onClick={() => setLocation("/profile")}
            data-testid="button-profile"
          >
            <UserIcon className="h-5 w-5 text-gray-600" />
          </Button>
        </div>
      </div>

      {/* Daily Progress Overview */}
      <div className="px-6 py-6 bg-white">
        <h2 className="font-semibold text-lg text-neutral-800 mb-4">Today's Progress</h2>
        
        {/* Calories Circle Progress */}
        <div className="flex items-center justify-center mb-6">
          <div className="relative w-32 h-32">
            <svg className="w-32 h-32 -rotate-90" viewBox="0 0 36 36">
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="rgb(229, 231, 235)"
                strokeWidth="2"
              />
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="rgb(16, 185, 129)"
                strokeWidth="2"
                strokeDasharray={`${Math.min(caloriesProgress, 100)}, 100`}
                className="circular-progress"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center flex-col">
              <span className="text-2xl font-bold text-neutral-800" data-testid="text-calories-consumed">
                {todayProgress.totalCalories || 0}
              </span>
              <span className="text-xs text-gray-600">
                of <span data-testid="text-calories-target">{user.dailyCalorieTarget}</span>
              </span>
              <span className="text-xs text-gray-500">calories</span>
            </div>
          </div>
        </div>

        {/* Macros Breakdown */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <Progress value={proteinProgress} className="mb-2 h-2" />
            <div className="text-sm font-medium text-neutral-800" data-testid="text-protein">
              {Math.round(todayProgress.totalProtein || 0)}g
            </div>
            <div className="text-xs text-gray-500">Protein</div>
          </div>
          <div className="text-center">
            <Progress value={carbsProgress} className="mb-2 h-2" />
            <div className="text-sm font-medium text-neutral-800" data-testid="text-carbs">
              {Math.round(todayProgress.totalCarbs || 0)}g
            </div>
            <div className="text-xs text-gray-500">Carbs</div>
          </div>
          <div className="text-center">
            <Progress value={fatsProgress} className="mb-2 h-2" />
            <div className="text-sm font-medium text-neutral-800" data-testid="text-fats">
              {Math.round(todayProgress.totalFats || 0)}g
            </div>
            <div className="text-xs text-gray-500">Fats</div>
          </div>
        </div>
      </div>

      {/* Recent Meals */}
      <div className="flex-1 px-6 py-4 bg-gray-50 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-neutral-800">Recent Meals</h3>
          <Button variant="ghost" className="text-primary text-sm font-medium" data-testid="button-view-all-meals">
            View All
          </Button>
        </div>
        
        <div className="space-y-3 pb-32">
          {recentMeals && recentMeals.length > 0 ? (
            recentMeals.slice(0, 5).map((meal) => (
              <Card key={meal.id} className="shadow-sm">
                <CardContent className="p-4 flex items-center space-x-3">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl flex items-center justify-center">
                    <Camera className="text-primary" size={20} />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-neutral-800" data-testid={`text-meal-name-${meal.id}`}>
                      {meal.name}
                    </div>
                    <div className="text-sm text-gray-600" data-testid={`text-meal-time-${meal.id}`}>
                      {meal.loggedAt ? new Date(meal.loggedAt).toLocaleTimeString('en-US', {
                        hour: 'numeric',
                        minute: '2-digit',
                        hour12: true
                      }) : 'Unknown time'}
                    </div>
                    <div className="text-sm text-gray-500">
                      <span data-testid={`text-meal-calories-${meal.id}`}>{meal.calories} cal</span> • 
                      <span data-testid={`text-meal-protein-${meal.id}`}> {Math.round(meal.protein)}g protein</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="shadow-sm">
              <CardContent className="p-8 text-center">
                <Camera className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600 mb-4">No meals logged yet today</p>
                <Button
                  onClick={() => setShowCameraModal(true)}
                  className="bg-primary text-white"
                  data-testid="button-log-first-meal"
                >
                  Log Your First Meal
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Camera FAB */}
      <Button
        className="fixed bottom-24 right-6 w-16 h-16 rounded-full shadow-xl bg-primary hover:bg-primary/90"
        onClick={() => setShowCameraModal(true)}
        data-testid="button-camera-fab"
      >
        <Camera className="h-6 w-6" />
      </Button>

      {/* Modals */}
      <CameraModal
        isOpen={showCameraModal}
        onClose={() => setShowCameraModal(false)}
        onAnalysisComplete={handleAnalysisComplete}
      />

      {analysisResult && (
        <AnalysisModal
          isOpen={showAnalysisModal}
          onClose={() => setShowAnalysisModal(false)}
          analysis={analysisResult}
          imageUrl={analysisImage}
          userId={currentUserId!}
          onMealLogged={handleMealLogged}
        />
      )}

      <BottomNavigation activeTab="home" />
    </div>
  );
}
