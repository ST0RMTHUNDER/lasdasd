import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import BottomNavigation from "@/components/bottom-navigation";
import ProgressChart from "@/components/progress-chart";
import { Flame, Target, Medal } from "lucide-react";
import type { User, DailyProgress } from "@shared/schema";

export default function ProgressPage() {
  const currentUserId = localStorage.getItem("currentUserId");

  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", currentUserId],
    enabled: !!currentUserId,
  });

  const { data: progressData } = useQuery<DailyProgress[]>({
    queryKey: ["/api/progress", currentUserId, "range", {
      startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0]
    }],
    enabled: !!currentUserId,
  });

  if (!user) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading progress data...</p>
        </div>
      </div>
    );
  }

  const latestProgress = progressData?.[progressData.length - 1];
  const weightLoss = user.weight - (latestProgress?.currentWeight || user.weight);
  const avgCalories = progressData && progressData.length > 0 
    ? progressData.reduce((sum, day) => sum + (day.totalCalories || 0), 0) / progressData.length 
    : 0;
  const avgProtein = progressData && progressData.length > 0
    ? progressData.reduce((sum, day) => sum + (day.totalProtein || 0), 0) / progressData.length
    : 0;

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <div className="h-6 bg-white"></div>
      
      {/* Header */}
      <div className="bg-white px-6 py-4 border-b border-gray-100">
        <h1 className="text-2xl font-bold text-neutral-800" data-testid="text-progress-title">Progress</h1>
        <p className="text-gray-600 text-sm">Track your fitness journey</p>
      </div>

      <div className="flex-1 overflow-y-auto pb-20">
        {/* Weight Progress Chart */}
        <div className="bg-white px-6 py-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-lg text-neutral-800">Weight Trend</h2>
            <Select defaultValue="30days">
              <SelectTrigger className="w-40" data-testid="select-time-range">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30days">Last 30 days</SelectItem>
                <SelectItem value="3months">Last 3 months</SelectItem>
                <SelectItem value="6months">Last 6 months</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <ProgressChart data={progressData || []} />
          
          {/* Stats Cards */}
          <div className="grid grid-cols-3 gap-4 mt-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-800" data-testid="text-weight-lost">
                {weightLoss > 0 ? `-${weightLoss.toFixed(1)}kg` : `+${Math.abs(weightLoss).toFixed(1)}kg`}
              </div>
              <div className="text-xs text-gray-500">Change</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-800" data-testid="text-current-weight">
                {(latestProgress?.currentWeight || user.weight).toFixed(1)}kg
              </div>
              <div className="text-xs text-gray-500">Current</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-800" data-testid="text-target-weight">
                {user.targetWeight}kg
              </div>
              <div className="text-xs text-gray-500">Target</div>
            </div>
          </div>
        </div>

        {/* Nutrition Insights */}
        <div className="bg-gray-50 px-6 py-6">
          <h3 className="font-semibold text-neutral-800 mb-4">Weekly Averages</h3>
          
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Daily Calories</span>
                  <span className="text-lg font-bold text-neutral-800" data-testid="text-avg-calories">
                    {Math.round(avgCalories)}
                  </span>
                </div>
                <Progress 
                  value={(avgCalories / user.dailyCalorieTarget!) * 100} 
                  className="mb-1"
                />
                <div className="text-xs text-gray-500">
                  {Math.round((avgCalories / user.dailyCalorieTarget!) * 100)}% of target
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Protein Intake</span>
                  <span className="text-lg font-bold text-neutral-800" data-testid="text-avg-protein">
                    {Math.round(avgProtein)}g
                  </span>
                </div>
                <Progress 
                  value={user.proteinTarget ? (avgProtein / user.proteinTarget) * 100 : 0} 
                  className="mb-1"
                />
                <div className="text-xs text-gray-500">
                  {user.proteinTarget && avgProtein > user.proteinTarget ? 'Above' : 'Below'} recommended
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Achievement Badges */}
        <div className="bg-white px-6 py-6 mb-20">
          <h3 className="font-semibold text-neutral-800 mb-4">Recent Achievements</h3>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Flame className="text-accent" size={24} />
              </div>
              <div className="text-xs font-medium text-gray-700" data-testid="text-streak-badge">7-Day Streak</div>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Target className="text-primary" size={24} />
              </div>
              <div className="text-xs font-medium text-gray-700" data-testid="text-goal-badge">Goal Achiever</div>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                <Medal className="text-secondary" size={24} />
              </div>
              <div className="text-xs font-medium text-gray-700" data-testid="text-consistency-badge">Consistency King</div>
            </div>
          </div>
        </div>
      </div>

      <BottomNavigation activeTab="progress" />
    </div>
  );
}
