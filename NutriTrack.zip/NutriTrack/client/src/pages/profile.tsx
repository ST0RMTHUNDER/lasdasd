import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import BottomNavigation from "@/components/bottom-navigation";
import { User as UserIcon, Settings, Target, Activity, Mail, Calendar } from "lucide-react";
import type { User } from "@shared/schema";

export default function Profile() {
  const currentUserId = localStorage.getItem("currentUserId");

  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", currentUserId],
    enabled: !!currentUserId,
  });

  if (!user) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  const getGoalText = (goal: string) => {
    switch (goal) {
      case 'lose_weight': return 'Lose Weight';
      case 'build_muscle': return 'Build Muscle';
      case 'maintain_weight': return 'Maintain Weight';
      default: return goal;
    }
  };

  const getActivityText = (level: string) => {
    switch (level) {
      case 'sedentary': return 'Sedentary';
      case 'lightly_active': return 'Lightly Active';
      case 'moderately_active': return 'Moderately Active';
      case 'very_active': return 'Very Active';
      case 'extremely_active': return 'Extremely Active';
      default: return level;
    }
  };

  const getTimelineText = (timeline: string) => {
    switch (timeline) {
      case '1_month': return '1 Month';
      case '3_months': return '3 Months';
      case '6_months': return '6 Months';
      case '1_year': return '1 Year';
      case '2_years': return '2+ Years';
      default: return timeline;
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      <div className="h-6 bg-white"></div>
      
      {/* Header */}
      <div className="bg-white px-6 py-4 border-b border-gray-100">
        <h1 className="text-2xl font-bold text-neutral-800" data-testid="text-profile-title">Profile</h1>
        <p className="text-gray-600 text-sm">Manage your account and preferences</p>
      </div>

      <div className="flex-1 overflow-y-auto pb-20">
        {/* Profile Info */}
        <div className="bg-white px-6 py-6">
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
              <UserIcon className="text-white" size={32} />
            </div>
            <div>
              <h2 className="text-xl font-bold text-neutral-800" data-testid="text-username">
                {user.username}
              </h2>
              <p className="text-gray-600" data-testid="text-email">{user.email}</p>
              <p className="text-sm text-primary font-medium">
                Goal: {getGoalText(user.goal)}
              </p>
            </div>
          </div>

          <Button className="w-full" data-testid="button-edit-profile">
            <Settings className="mr-2 h-4 w-4" />
            Edit Profile
          </Button>
        </div>

        {/* Personal Information */}
        <div className="px-6 py-4">
          <h3 className="font-semibold text-neutral-800 mb-4">Personal Information</h3>
          
          <div className="space-y-3">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Age</span>
                  </div>
                  <span className="font-medium" data-testid="text-age">{user.age} years</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <UserIcon className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Gender</span>
                  </div>
                  <span className="font-medium" data-testid="text-gender">
                    {user.gender.charAt(0).toUpperCase() + user.gender.slice(1)}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Activity className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Height</span>
                  </div>
                  <span className="font-medium" data-testid="text-height">{user.height} cm</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Activity className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Current Weight</span>
                  </div>
                  <span className="font-medium" data-testid="text-current-weight">{user.weight} kg</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Target className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Target Weight</span>
                  </div>
                  <span className="font-medium" data-testid="text-target-weight">{user.targetWeight} kg</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Fitness Goals */}
        <div className="px-6 py-4">
          <h3 className="font-semibold text-neutral-800 mb-4">Fitness Goals</h3>
          
          <div className="space-y-3">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Target className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Primary Goal</span>
                  </div>
                  <span className="font-medium" data-testid="text-primary-goal">
                    {getGoalText(user.goal)}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Activity className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Activity Level</span>
                  </div>
                  <span className="font-medium" data-testid="text-activity-level">
                    {getActivityText(user.activityLevel)}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-gray-500" />
                    <span className="text-gray-700">Timeline</span>
                  </div>
                  <span className="font-medium" data-testid="text-timeline">
                    {getTimelineText(user.timeline)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Daily Targets */}
        <div className="px-6 py-4">
          <h3 className="font-semibold text-neutral-800 mb-4">Daily Targets</h3>
          
          <div className="grid grid-cols-2 gap-3">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary" data-testid="text-calorie-target">
                  {user.dailyCalorieTarget}
                </div>
                <div className="text-sm text-gray-600">Calories</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600" data-testid="text-protein-target">
                  {user.proteinTarget}g
                </div>
                <div className="text-sm text-gray-600">Protein</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-600" data-testid="text-carbs-target">
                  {user.carbsTarget}g
                </div>
                <div className="text-sm text-gray-600">Carbs</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600" data-testid="text-fats-target">
                  {user.fatsTarget}g
                </div>
                <div className="text-sm text-gray-600">Fats</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <BottomNavigation activeTab="profile" />
    </div>
  );
}
