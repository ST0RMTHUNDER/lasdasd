import { type User, type InsertUser, type Meal, type InsertMeal, type DailyProgress, type InsertDailyProgress } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;

  // Meal operations
  getMeal(id: string): Promise<Meal | undefined>;
  getMealsByUser(userId: string, limit?: number): Promise<Meal[]>;
  createMeal(meal: InsertMeal): Promise<Meal>;
  
  // Daily progress operations
  getDailyProgress(userId: string, date: string): Promise<DailyProgress | undefined>;
  getDailyProgressRange(userId: string, startDate: string, endDate: string): Promise<DailyProgress[]>;
  createOrUpdateDailyProgress(progress: InsertDailyProgress): Promise<DailyProgress>;
}

// Calculate BMR and daily calorie targets
function calculateTargets(user: InsertUser) {
  const { age, gender, height, weight, activityLevel, goal } = user;
  
  // Mifflin-St Jeor Equation
  let bmr: number;
  if (gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  } else {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }
  
  // Activity multipliers
  const activityMultipliers: Record<string, number> = {
    'sedentary': 1.2,
    'lightly_active': 1.375,
    'moderately_active': 1.55,
    'very_active': 1.725,
    'extremely_active': 1.9
  };
  
  const tdee = bmr * (activityMultipliers[activityLevel] || 1.2);
  
  // Goal adjustments
  let dailyCalorieTarget = tdee;
  if (goal === 'lose_weight') {
    dailyCalorieTarget = tdee - 500; // 500 calorie deficit
  } else if (goal === 'build_muscle') {
    dailyCalorieTarget = tdee + 300; // 300 calorie surplus
  }
  
  // Macro targets (protein: 25%, carbs: 45%, fats: 30%)
  const proteinTarget = Math.round((dailyCalorieTarget * 0.25) / 4);
  const carbsTarget = Math.round((dailyCalorieTarget * 0.45) / 4);
  const fatsTarget = Math.round((dailyCalorieTarget * 0.30) / 9);
  
  return {
    dailyCalorieTarget: Math.round(dailyCalorieTarget),
    proteinTarget,
    carbsTarget,
    fatsTarget
  };
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private meals: Map<string, Meal>;
  private dailyProgress: Map<string, DailyProgress>;

  constructor() {
    this.users = new Map();
    this.meals = new Map();
    this.dailyProgress = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const targets = calculateTargets(insertUser);
    const user: User = { 
      ...insertUser, 
      id,
      ...targets,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getMeal(id: string): Promise<Meal | undefined> {
    return this.meals.get(id);
  }

  async getMealsByUser(userId: string, limit: number = 50): Promise<Meal[]> {
    return Array.from(this.meals.values())
      .filter(meal => meal.userId === userId)
      .sort((a, b) => new Date(b.loggedAt!).getTime() - new Date(a.loggedAt!).getTime())
      .slice(0, limit);
  }

  async createMeal(insertMeal: InsertMeal): Promise<Meal> {
    const id = randomUUID();
    const meal: Meal = { 
      ...insertMeal, 
      id,
      imageUrl: insertMeal.imageUrl || null,
      fiber: insertMeal.fiber || null,
      sodium: insertMeal.sodium || null,
      sugar: insertMeal.sugar || null,
      analysisData: insertMeal.analysisData || null,
      loggedAt: new Date()
    };
    this.meals.set(id, meal);
    
    // Update daily progress
    const today = new Date().toISOString().split('T')[0];
    const existingProgress = await this.getDailyProgress(insertMeal.userId, today);
    
    const progressData: InsertDailyProgress = {
      userId: insertMeal.userId,
      date: today,
      totalCalories: (existingProgress?.totalCalories || 0) + insertMeal.calories,
      totalProtein: (existingProgress?.totalProtein || 0) + insertMeal.protein,
      totalCarbs: (existingProgress?.totalCarbs || 0) + insertMeal.carbs,
      totalFats: (existingProgress?.totalFats || 0) + insertMeal.fats,
      currentWeight: existingProgress?.currentWeight
    };
    
    await this.createOrUpdateDailyProgress(progressData);
    
    return meal;
  }

  async getDailyProgress(userId: string, date: string): Promise<DailyProgress | undefined> {
    const key = `${userId}-${date}`;
    return this.dailyProgress.get(key);
  }

  async getDailyProgressRange(userId: string, startDate: string, endDate: string): Promise<DailyProgress[]> {
    return Array.from(this.dailyProgress.values())
      .filter(progress => 
        progress.userId === userId && 
        progress.date >= startDate && 
        progress.date <= endDate
      )
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  async createOrUpdateDailyProgress(insertProgress: InsertDailyProgress): Promise<DailyProgress> {
    const key = `${insertProgress.userId}-${insertProgress.date}`;
    const existing = this.dailyProgress.get(key);
    
    let progress: DailyProgress;
    if (existing) {
      progress = { ...existing, ...insertProgress };
    } else {
      const id = randomUUID();
      progress = { 
        ...insertProgress, 
        id,
        totalCalories: insertProgress.totalCalories || null,
        totalProtein: insertProgress.totalProtein || null,
        totalCarbs: insertProgress.totalCarbs || null,
        totalFats: insertProgress.totalFats || null,
        currentWeight: insertProgress.currentWeight || null
      };
    }
    
    this.dailyProgress.set(key, progress);
    return progress;
  }
}

export const storage = new MemStorage();
