import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "your-api-key-here"
});

export interface NutritionAnalysis {
  foodItems: string[];
  totalCalories: number;
  protein: number;
  carbs: number;
  fats: number;
  fiber?: number;
  sodium?: number;
  sugar?: number;
  confidence: number;
  description: string;
}

export async function analyzeMealPhoto(base64Image: string): Promise<NutritionAnalysis> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a professional nutritionist and food analyst. Analyze the food image and provide detailed nutritional information. Be as accurate as possible in identifying food items and estimating portions. Return your analysis as JSON in this exact format:

{
  "foodItems": ["item 1 with estimated portion", "item 2 with estimated portion"],
  "totalCalories": number,
  "protein": number (in grams),
  "carbs": number (in grams),
  "fats": number (in grams),
  "fiber": number (in grams, optional),
  "sodium": number (in mg, optional),
  "sugar": number (in grams, optional),
  "confidence": number (0-1, how confident you are in this analysis),
  "description": "detailed description of identified foods and portions"
}`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Please analyze this meal photo and provide detailed nutritional information. Identify all visible food items, estimate portion sizes, and calculate the total nutritional values."
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }

    const analysis = JSON.parse(content) as NutritionAnalysis;
    
    // Validate required fields
    if (!analysis.totalCalories || !analysis.protein || !analysis.carbs || !analysis.fats) {
      throw new Error("Invalid analysis response - missing required nutritional data");
    }

    return analysis;
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    throw new Error(`Failed to analyze meal photo: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
