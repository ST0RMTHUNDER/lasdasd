import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMealSchema } from "@shared/schema";
import { analyzeMealPhoto } from "./services/openai";
import multer from "multer";
import { z } from "zod";

// Configure multer for memory storage (base64 images)
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // User registration and profile
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      console.error("Create user error:", error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid user data" 
      });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Failed to get user" });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const updates = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Meal analysis and logging
  app.post("/api/analyze-meal", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No image file provided" });
      }

      const base64Image = req.file.buffer.toString('base64');
      const analysis = await analyzeMealPhoto(base64Image);
      
      res.json(analysis);
    } catch (error) {
      console.error("Meal analysis error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to analyze meal"
      });
    }
  });

  app.post("/api/analyze-meal-base64", async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        return res.status(400).json({ message: "No base64 image provided" });
      }

      // Remove data URL prefix if present
      const base64Image = image.replace(/^data:image\/[a-z]+;base64,/, '');
      const analysis = await analyzeMealPhoto(base64Image);
      
      res.json(analysis);
    } catch (error) {
      console.error("Meal analysis error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to analyze meal"
      });
    }
  });

  app.post("/api/meals", async (req, res) => {
    try {
      const mealData = insertMealSchema.parse(req.body);
      const meal = await storage.createMeal(mealData);
      res.json(meal);
    } catch (error) {
      console.error("Create meal error:", error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Invalid meal data" 
      });
    }
  });

  app.get("/api/meals/:userId", async (req, res) => {
    try {
      const { limit = "20" } = req.query;
      const meals = await storage.getMealsByUser(
        req.params.userId, 
        parseInt(limit as string)
      );
      res.json(meals);
    } catch (error) {
      console.error("Get meals error:", error);
      res.status(500).json({ message: "Failed to get meals" });
    }
  });

  // Daily progress and analytics
  app.get("/api/progress/:userId/today", async (req, res) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const progress = await storage.getDailyProgress(req.params.userId, today);
      res.json(progress || {
        userId: req.params.userId,
        date: today,
        totalCalories: 0,
        totalProtein: 0,
        totalCarbs: 0,
        totalFats: 0
      });
    } catch (error) {
      console.error("Get today's progress error:", error);
      res.status(500).json({ message: "Failed to get today's progress" });
    }
  });

  app.get("/api/progress/:userId/range", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const progress = await storage.getDailyProgressRange(
        req.params.userId,
        startDate as string,
        endDate as string
      );
      res.json(progress);
    } catch (error) {
      console.error("Get progress range error:", error);
      res.status(500).json({ message: "Failed to get progress range" });
    }
  });

  app.post("/api/progress", async (req, res) => {
    try {
      const progressData = req.body;
      const progress = await storage.createOrUpdateDailyProgress(progressData);
      res.json(progress);
    } catch (error) {
      console.error("Update progress error:", error);
      res.status(500).json({ message: "Failed to update progress" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
